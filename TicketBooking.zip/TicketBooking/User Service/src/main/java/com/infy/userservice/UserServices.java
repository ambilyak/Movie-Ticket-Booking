package com.infy.userservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServices {
	
	@Autowired
    public UserRepository repo;
    
    
    public List<User> getAllUser(){
        List<User> userlist= new ArrayList<>();
//      repo.findAll().forEach(users::add); 
 		Iterable<User> users =repo.findAll();
 		users.forEach(userlist::add);
        return userlist;      
    }
    
    public String userAsAdmin(String username){
    	Optional<User> user=repo.findById(username);
    	user.get().setRole("Admin");
    	return username+" is now an Admin";
    }
    public User addUser(User user) {
    	user.setRole("User");
        return repo.save(user);
    }
    
    public User updateDetails(User user) {
        return repo.save(user);
    }
    
    public void deleteByUsername(String username) {      
            repo.deleteById(username);        
    }
    
    public Optional<User> findUser(String id) {        
        Optional<User> users = repo.findById(id);
        return users;
    }
        
    public String login (Login loginuser)
    {
        User user=null;
        Optional <User> optuser=repo.findById(loginuser.getUserName());
        
        if(optuser.isPresent()) {
            user=optuser.get();
            if(user.getPassword().equals(loginuser.getPassword())) {
                return "successfully login";
            }
            
            else {
                return "failed login";
                
            }
        }
            else {
            return "No user present";
            }
      }
			

}
	

