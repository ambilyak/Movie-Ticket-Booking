package com.infy.movieservice;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class MovieController {
	
	@Autowired
	private MovieServices service;
	
    @GetMapping("/allmovies")           
    public ResponseEntity<List<Movie>> getAllMovies(){
    return new ResponseEntity<>(service.getAllMovies(),HttpStatus.OK);
   }
   
   @GetMapping(path = "/getmovie/{movieId}")
   public ResponseEntity<Optional<Movie>> findMovie(@PathVariable("movieId") Integer movieId){
       return new ResponseEntity<>(service.findMovie(movieId),HttpStatus.OK);  
   }
   
   @RequestMapping( method=RequestMethod.POST, value="/addmovie")
   public ResponseEntity<Movie> addMovie(@Valid @RequestBody Movie movie){
       return new ResponseEntity<>(service.addMovie(movie), HttpStatus.OK);
   }
   
   @RequestMapping(method=RequestMethod.PUT, value="/updatemovie/{id}")
   public ResponseEntity<Movie> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Movie movie){
       return new ResponseEntity<>(service.updateDetails(id,movie), HttpStatus.OK);
   }
   
   @DeleteMapping(path = "/deletemovie/{movieId}")
   public ResponseEntity <Void> deleteMovie(@PathVariable("movieId") Integer movieId){
   service.deleteMovie(movieId);
   return new ResponseEntity<Void>(HttpStatus.OK);   
   }
   
}
