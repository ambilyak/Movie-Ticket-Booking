package com.infy.bookingservice;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.ParseException;

@Service
public class BookingServices {
	
	@Autowired
	public BookingRepository bookingrepo;
	
	@Autowired
	public ShowRepository showrepo;
	
	public List<Booking> getAllBookings(){
        List<Booking> allbookings= new ArrayList<>();
        bookingrepo.findAll().forEach(allbookings::add);
        return allbookings;       
	}
	
	public List<Booking> getBookings(String fromDate,String toDate){
        List<Booking> allbookings= new ArrayList<>();
        List<Booking> bookinglist= new ArrayList<>();
        bookingrepo.findAll().forEach(allbookings::add);      
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date startdate = null;
        Date enddate = null; 
        try {
        	startdate = dateFormat.parse(fromDate);
        	enddate = dateFormat.parse(toDate);
        } 
        catch (ParseException e) {
            e.printStackTrace();
        }
//        System.out.println("startdate " + startdate.toString());
//        System.out.println("enddate " + enddate.toString());
        
        for(Booking booking : allbookings){       
           if((booking.getShowId().getShowDate().after(startdate)||booking.getShowId().getShowDate().equals(startdate))
        		   &&(booking.getShowId().getShowDate().before(enddate)||booking.getShowId().getShowDate().equals(enddate))) {    
        	   bookinglist.add(booking);
           }
        }
        return bookinglist;
	}
	
    public Booking addBooking(Booking booking) throws Exception{   	
    	Optional<Show> show=showrepo.findById((booking.getShowId().getShowId()));
    	 if(show.get().getSeatAvailability()<booking.getSeatsBooked()) {
             throw new Exception("Seat Unavailable");
    	 }
    	 else {
	    	Integer rate=(show.get().getRate());
	    	Integer amount=booking.getSeatsBooked()*rate;
	    	Integer seats=show.get().getSeatAvailability()-booking.getSeatsBooked();
	    	show.get().setSeatAvailability(seats);
	    	booking.setShowId(show.get());
	    	booking.setAmount(amount);
	    	booking.setStatus("Booked");
	        return bookingrepo.save(booking);   
    	 }
    }

    public Optional<Booking> deleteBooking(Integer bookingId) {   
    	Optional<Booking> booking=bookingrepo.findById(bookingId);
    	Show show=booking.get().getShowId();
    	Integer seats=show.getSeatAvailability()+booking.get().getSeatsBooked();
    	show.setSeatAvailability(seats);
    	booking.get().setStatus("Cancelled");
    	bookingrepo.save(booking.get());
    	return booking;
    }
	
    public List<Show> getAllShows(){
        List<Show> showlist= new ArrayList<>();
 		Iterable<Show> shows =showrepo.findAll();
 		shows.forEach(showlist::add);
        return showlist;      
    }
    
    public Optional<Show> findShow(Integer id) {        
        Optional<Show> show = showrepo.findById(id);
        return show;
    }
    
    public List<Show> findShowByMoive(Integer movieId) {        
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
        	if(show.getMovieId().getMovieId().equals(movieId)) {
        		shows.add(show);
        	}
        }
        return shows;      
    }
    
    public List<Show> findShowByTheatre(Integer theatreId) {        
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
        	if(show.getTheatreId().getTheatreId().equals(theatreId)) {
        		shows.add(show);
        	}
        }
        return shows;      
    }
    
    public Show addShow(Show show) {
        return showrepo.save(show);
    }
    
    public Show updateDetails(Integer showId,Show show) {
    	show.setShowId(showId);
        return showrepo.save(show);
    }
    
    public void deleteShow(Integer showId) {      
        showrepo.deleteById(showId);        
    }

	
}
