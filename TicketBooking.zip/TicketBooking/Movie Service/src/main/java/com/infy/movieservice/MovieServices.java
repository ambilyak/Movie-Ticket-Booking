package com.infy.movieservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class MovieServices {
	
	@Autowired
	public MovieRepository repo;
	
    public List<Movie> getAllMovies(){
        List<Movie> movielist= new ArrayList<>();
 		Iterable<Movie> movies =repo.findAll();
 		movies.forEach(movielist::add);
        return movielist;      
    }
    
    public Optional<Movie> findMovie(Integer id) {        
        Optional<Movie> movie = repo.findById(id);
        return movie;
    }
    
    public Movie addMovie(Movie movie) {
        return repo.save(movie);
    }
    
    public Movie updateDetails(Integer movieId,Movie movie) {
    	movie.setMovieId(movieId);
        return repo.save(movie);
    }
    
    public void deleteMovie(Integer movieId) {      
        repo.deleteById(movieId);        
    }
    
}
