package com.infy.bookingservice;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;


@CrossOrigin
@RestController
public class BookingController {
	
	@Autowired
	private BookingServices service;
	
   @GetMapping(path = "/getallbooking")
   public ResponseEntity<List<Booking>> getAllBookings(){
       return new ResponseEntity<>(service.getAllBookings(),HttpStatus.OK);  
   }
   
   @GetMapping(path = "/getbooking/{username}")
   public ResponseEntity<List<Booking>> getuserBookings(@PathVariable("username") String userName){
       return new ResponseEntity<>(service.getuserBookings(userName),HttpStatus.OK);  
   }
	
   @GetMapping(path = "/getbooking/{fromDate}/{toDate}")
   public ResponseEntity<List<Booking>> getBookings(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate){
       return new ResponseEntity<>(service.getBookings(fromDate,toDate),HttpStatus.OK);  
   }
	
   @RequestMapping( method=RequestMethod.POST, value="/addbooking")
   public ResponseEntity<Booking> addBooking(@Valid @RequestBody Booking booking)throws Exception{
	   try {
		   return new ResponseEntity<>(service.addBooking(booking), HttpStatus.OK);
	   }
	   catch (Exception e) {
           throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(),e);
       }
       
   }
   
   @DeleteMapping(path = "/deletebooking/{bookingId}")
   public ResponseEntity <Optional<Booking>> deleteBooking(@PathVariable("bookingId") Integer bookingId){
   return new ResponseEntity<Optional<Booking>>(service.deleteBooking(bookingId),HttpStatus.OK);   
   }
	
    @GetMapping("/allshows")           
    public ResponseEntity<List<Show>> getAllShows(){
    return new ResponseEntity<>(service.getAllShows(),HttpStatus.OK);
   }
   
   @GetMapping(path = "/getshow/{showId}")
   public ResponseEntity<Optional<Show>> findShow(@PathVariable("showId") Integer showId){
       return new ResponseEntity<>(service.findShow(showId),HttpStatus.OK);  
   }
   
   @GetMapping(path = "/getshowbymovie/{movieId}")
   public ResponseEntity<List<Show>> findShowByMoive(@PathVariable("movieId") Integer movieId){
       return new ResponseEntity<>(service.findShowByMoive(movieId),HttpStatus.OK);  
   }
   
   @GetMapping(path = "/getshowbytheatre/{theatreId}")
   public ResponseEntity<List<Show>> findShowByTheatre(@PathVariable("theatreId") Integer theatreId){
       return new ResponseEntity<>(service.findShowByTheatre(theatreId),HttpStatus.OK);  
   }
   
   @RequestMapping( method=RequestMethod.POST, value="/addshow")
   public ResponseEntity<Show> addShow(@Valid @RequestBody Show show){
       return new ResponseEntity<>(service.addShow(show), HttpStatus.OK);
   }
   
   @RequestMapping(method=RequestMethod.PUT, value="/updateshow/{id}")
   public ResponseEntity<Show> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Show show){
       return new ResponseEntity<>(service.updateDetails(id,show), HttpStatus.OK);
   }
   
   @DeleteMapping(path = "/deleteshow/{showId}")
   public ResponseEntity <Void> deleteShow(@PathVariable("showId") Integer showId){
   service.deleteShow(showId);
   return new ResponseEntity<Void>(HttpStatus.OK);   
   }
   

}
