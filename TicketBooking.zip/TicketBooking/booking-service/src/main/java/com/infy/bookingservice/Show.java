package com.infy.bookingservice;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "show_table")
public class Show {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer showId;
	@OneToOne
	private Movie movieId;
	@OneToOne
	private Theatre theatreId;
	private Date showDate;
	private String showTime;
	private Integer seatAvailability;
	private Integer rate;
	
	public Show() {
		super();
	}
	
	public Show(Integer showId, Movie movieId, Theatre theatreId, Date showDate, String showTime, Integer seatAvailability,
			Integer rate) {
		super();
		this.showId = showId;
		this.movieId = movieId;
		this.theatreId = theatreId;
		this.showDate = showDate;
		this.showTime = showTime;
		this.seatAvailability = seatAvailability;
		this.rate = rate;
	}
	public Integer getShowId() {
		return showId;
	}
	public void setShowId(Integer showId) {
		this.showId = showId;
	}
	public Movie getMovieId() {
		return movieId;
	}
	public void setMovieId(Movie movieId) {
		this.movieId = movieId;
	}
	public Theatre getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(Theatre theatreId) {
		this.theatreId = theatreId;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public String getShowTime() {
		return showTime;
	}
	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}
	public int getSeatAvailability() {
		return seatAvailability;
	}
	public void setSeatAvailability(Integer seatAvailability) {
		this.seatAvailability = seatAvailability;
	}
	public Integer getRate() {
		return rate;
	}
	public void setRate(Integer rate) {
		this.rate = rate;
	}
	
}
