package com.infy.bookingservice;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "booking")
public class Booking {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer bookingId;
	@OneToOne
	private User userName;
	@OneToOne
	private Show showId;	
	private Integer seatsBooked;
	private Integer amount;
	private String status;
	
	
	public Booking() {
		super();
	}

	public Booking(Integer bookingId, User userName, Show showId, Integer seatsBooked, Integer amount,String status) {
		super();
		this.bookingId = bookingId;
		this.userName = userName;
		this.showId = showId;
		this.seatsBooked = seatsBooked;
		this.amount = amount;
		this.status = status;
	}
	
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public User getUserName() {
		return userName;
	}
	public void setUserName(User userName) {
		this.userName = userName;
	}
	public Show getShowId() {
		return showId;
	}
	public void setShowId(Show showId) {
		this.showId = showId;
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}
	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
