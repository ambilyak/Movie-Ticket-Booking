package com.infy.theatreservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class TheatreServices {

	@Autowired
	public TheatreRepository repo;
	
    public List<Theatre> getAllTheatres(){
        List<Theatre> theatrelist= new ArrayList<>();
 		Iterable<Theatre> theatres =repo.findAll();
 		theatres.forEach(theatrelist::add);
        return theatrelist;      
    }
    
    public Optional<Theatre> findTheatre(Integer id) {        
        Optional<Theatre> theatre = repo.findById(id);
        return theatre;
    }
    
    public Theatre addTheatre(Theatre theatre) {
        return repo.save(theatre);
    }
    
    public Theatre updateDetails(Integer theatreId,Theatre theatre) {
    	theatre.setTheatreId(theatreId);
        return repo.save(theatre);
    }
    
    public void deleteTheatre(Integer theatreId) {      
        repo.deleteById(theatreId);        
    }
}
