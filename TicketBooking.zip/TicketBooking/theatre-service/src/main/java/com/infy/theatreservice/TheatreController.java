package com.infy.theatreservice;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class TheatreController {
	
	@Autowired
	private TheatreServices service;
	
    @GetMapping("/alltheatres")           
    public ResponseEntity<List<Theatre>> getAllTheatres(){
    return new ResponseEntity<>(service.getAllTheatres(),HttpStatus.OK);
   }
   
   @GetMapping(path = "/gettheatre/{theatreId}")
   public ResponseEntity<Optional<Theatre>> findTheatre(@PathVariable("theatreId") Integer theatreId){
       return new ResponseEntity<>(service.findTheatre(theatreId),HttpStatus.OK);  
   }
   
   @RequestMapping( method=RequestMethod.POST, value="/addtheatre")
   public ResponseEntity<Theatre> addTheatre(@Valid @RequestBody Theatre theatre){
       return new ResponseEntity<>(service.addTheatre(theatre), HttpStatus.OK);
   }
   
   @RequestMapping(method=RequestMethod.PUT, value="/updatetheatre/{id}")
   public ResponseEntity<Theatre> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Theatre theatre){
       return new ResponseEntity<>(service.updateDetails(id,theatre), HttpStatus.OK);
   }
   
   @DeleteMapping(path = "/deletetheatre/{theatreId}")
   public ResponseEntity <Void> deleteTheatre(@PathVariable("theatreId") Integer theatreId){
   service.deleteTheatre(theatreId);
   return new ResponseEntity<Void>(HttpStatus.OK);  
   }
   
}
